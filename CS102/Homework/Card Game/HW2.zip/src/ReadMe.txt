CS102 - Group Work - Card Game Homework

===================================

Group Members:

Berk Çakar 22003021

Borga Haktan Bilen 22002733

===================================